package com.aldobai.telecom

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val navy = Color.rgb(16, 53, 91)
    private val blue = Color.rgb(28, 105, 171)
    private val pale = Color.rgb(239, 245, 251)
    private var balance = 25000
    private val history = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun bg(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(text: String, size: Float = 16f, color: Int = navy, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(12, 10, 12, 10)
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            background = bg(blue, 14f)
            setOnClickListener { action() }
        }

    private fun base(title: String): LinearLayout {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            setPadding(18, 18, 18, 18)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = TextView(this).apply {
            text = "الدبعي تيليكوم\n$title"
            textSize = 22f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(16, 22, 16, 22)
            background = bg(navy, 20f)
        }
        page.addView(header, LinearLayout.LayoutParams(-1, -2))
        return page
    }

    private fun showHome() {
        val page = base("خدمات الاتصالات")
        val balanceCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(Color.WHITE, 18f)
            setPadding(12, 12, 12, 12)
        }
        balanceCard.addView(label("رصيدك التجريبي", 15f, blue, true))
        balanceCard.addView(label("%,d ريال".format(balance), 28f, navy, true))
        balanceCard.addView(label("هذا رصيد افتراضي للتجربة فقط — لا توجد أموال حقيقية", 12f, Color.DKGRAY))
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = 18
        page.addView(balanceCard, lp)

        page.addView(label("اختر الخدمة", 19f, navy, true))
        val services = listOf(
            "شحن يمن موبايل" to "Yemen Mobile",
            "شحن YOU" to "YOU",
            "شحن سبأفون" to "Sabafon",
            "شحن واي" to "Y",
            "باقات الإنترنت" to "Internet",
            "عدن نت" to "Aden Net",
            "تحويل رصيد تجريبي" to "Transfer",
            "سداد فاتورة تجريبية" to "Bills"
        )
        services.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { item ->
                val b = button(item.first) { showOperation(item.first) }
                val p = LinearLayout.LayoutParams(0, 58, 1f); p.setMargins(4, 4, 4, 4)
                row.addView(b, p)
            }
            page.addView(row)
        }
        page.addView(button("سجل العمليات") { showHistory() })
        page.addView(label("نسخة تجريبية 1.0", 12f, Color.GRAY))
        setContentView(page)
    }

    private fun showOperation(service: String) {
        val page = base(service)
        val number = EditText(this).apply {
            hint = "رقم الهاتف / الحساب"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            textSize = 16f; setPadding(14, 12, 14, 12); background = bg(Color.WHITE, 12f)
        }
        val amount = EditText(this).apply {
            hint = "المبلغ بالريال اليمني"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 16f; setPadding(14, 12, 14, 12); background = bg(Color.WHITE, 12f)
        }
        val nlp = LinearLayout.LayoutParams(-1, 58); nlp.topMargin = 22
        page.addView(number, nlp)
        val alp = LinearLayout.LayoutParams(-1, 58); alp.topMargin = 12
        page.addView(amount, alp)
        page.addView(label("تنبيه: العملية محاكاة فقط ولا تتصل بأي شبكة أو جهة دفع.", 13f, Color.rgb(160, 70, 30)))
        page.addView(button("تنفيذ العملية التجريبية") {
            val phone = number.text.toString().trim()
            val value = amount.text.toString().toIntOrNull()
            if (phone.length < 7 || value == null || value <= 0) {
                Toast.makeText(this, "أدخل رقمًا صحيحًا ومبلغًا أكبر من صفر", Toast.LENGTH_LONG).show()
            } else if (value > balance) {
                Toast.makeText(this, "الرصيد التجريبي غير كافٍ", Toast.LENGTH_LONG).show()
            } else {
                balance -= value
                history.add("$service — $phone — $value ريال — ناجحة (تجريبية)")
                AlertDialog.Builder(this)
                    .setTitle("تمت المحاكاة بنجاح")
                    .setMessage("الخدمة: $service\nالرقم: $phone\nالمبلغ: $value ريال\nالرصيد المتبقي: $balance ريال\n\nهذه ليست عملية حقيقية.")
                    .setPositiveButton("حسنًا") { _, _ -> showHome() }
                    .show()
            }
        })
        page.addView(button("رجوع للرئيسية") { showHome() })
        setContentView(page)
    }

    private fun showHistory() {
        val page = base("سجل العمليات")
        if (history.isEmpty()) page.addView(label("لا توجد عمليات حتى الآن"))
        else history.asReversed().forEach { page.addView(label(it, 14f, navy)) }
        page.addView(button("رجوع للرئيسية") { showHome() })
        setContentView(page)
    }
}
